package com.example.arcore_measure

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.google.ar.sceneform.assets.RenderableSource
import com.google.ar.sceneform.rendering.ModelRenderable
import com.google.ar.sceneform.rendering.Renderable

class MainActivity : AppCompatActivity() {

    private val  TAG = "MainActivity"
    private lateinit var Measure : Button
    private val buttonArrayList = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonArray = resources.getStringArray(R.array.arcore_measure_buttons)

        buttonArray.map{item->
            buttonArrayList.add(item)
        }


        Measure = findViewById(R.id.arcore_measure)
        Measure.text = buttonArrayList[0]
        Measure.setOnClickListener(object : View.OnClickListener{
            override fun onClick(v:View?) {
                val intent = Intent(application,MeasurementAPI::class.java)
                startActivity(intent)
            }
        })

    }
}