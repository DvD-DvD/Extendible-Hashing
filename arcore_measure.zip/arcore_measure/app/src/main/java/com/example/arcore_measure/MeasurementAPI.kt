package com.example.arcore_measure

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.*
import com.google.ar.core.*
import com.google.ar.sceneform.AnchorNode
import com.google.ar.sceneform.FrameTime
import com.google.ar.sceneform.Node
import com.google.ar.sceneform.Scene
import com.google.ar.sceneform.assets.RenderableSource
import com.google.ar.sceneform.math.Vector3
import com.google.ar.sceneform.rendering.*
import com.google.ar.sceneform.ux.ArFragment
import com.google.ar.sceneform.ux.TransformableNode
import com.google.ar.sceneform.rendering.Color as arColor
import java.util.Objects
import kotlin.math.pow
import kotlin.math.sqrt


class MeasurementAPI : AppCompatActivity(), Scene.OnUpdateListener {
    private val TAG: String = MeasurementAPI::class.java.simpleName
    private val MIN_OPENGL_VERSION = 3.0

    private var arFragment: ArFragment? = null
    private lateinit var arFragmentRender: ArFragment
    private val arSceneView get() = arFragmentRender.arSceneView
    //private val scene get() = arSceneView.scene

    private var _3DmodelName : String = "models/samsungTV.glb"

    private var distanceModeTextView: TextView? = null
    private lateinit var pointTextView: TextView
    var renderable3D : Renderable? = null


    private lateinit var distanceMatrix: TableLayout

    private var markerRenderable: ModelRenderable? = null     // a small 3D marker to be placed at tapped location
    private var distanceCardViewRenderable: ViewRenderable? = null

    private lateinit var distanceModeSpinner: Spinner
    private val distanceModeArrayList = ArrayList<String>()
    private var distanceMode: String = ""

    private val placedAnchors = ArrayList<Anchor>()
    private val placedAnchorNodes = ArrayList<AnchorNode>()

    private val midAnchors: MutableMap<String, Anchor> = mutableMapOf()
    private val midAnchorNodes: MutableMap<String, AnchorNode> = mutableMapOf()

    private val fromGroundNodes = ArrayList<List<Node>>()

    private val multipleDistances = Array(Constants.maxNumberOfPoints,
        {Array<TextView?>(Constants.maxNumberOfPoints){null} })
    private lateinit var zero_distance: String

    private lateinit var clearButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_measurement_api)
        checkDeviceSupportStatus(this) // ARCORE requirements check

        initToast()

        val distanceModeArray = resources.getStringArray(R.array.distance_mode)
        distanceModeArray.map{it->
            distanceModeArrayList.add(it)
        }




        arFragment = supportFragmentManager.findFragmentById(R.id.sceneform_fragment) as ArFragment?
        distanceModeTextView = findViewById(R.id.distance_view)
        distanceMatrix = findViewById(R.id.multiple_distance_table)

        zero_distance = resources.getString(R.string.zero_distance)

        configureSpinner()
        initRenderable()
        clearButton()


        arFragment!!.apply { setOnSessionInitializationListener {  } }
        arFragment!!.setOnTapArPlaneListener { hitResult: HitResult, plane: Plane?, motionEvent: MotionEvent? ->

            // Creating Anchor

            if (markerRenderable == null || distanceCardViewRenderable == null) return@setOnTapArPlaneListener
            when (distanceMode){
                distanceModeArrayList[0] -> {
                    clearAllAnchors()
                    placeAnchor(hitResult, distanceCardViewRenderable!!,false)
                }
                distanceModeArrayList[1] -> {
                    tapDistanceOf2Points(hitResult)
                }
                distanceModeArrayList[2] -> {
                    tapDistanceOfMultiplePoints(hitResult)
                }
                else -> {
                    clearAllAnchors()
                    placeAnchor(hitResult, distanceCardViewRenderable!!,false)
                }
            }
        }

        loadModel()


    }

    private fun loadModel(){
        ModelRenderable.builder().setSource(this, RenderableSource.builder().setSource(
            this, Uri.parse(_3DmodelName), RenderableSource.SourceType.GLB).build())
            .setRegistryId(_3DmodelName)
            .build()
            .thenAccept{ renderable3D = it }
            .exceptionally {
                Toast.makeText(this@MeasurementAPI,"Error loading 3D model",Toast.LENGTH_SHORT).show()
                return@exceptionally null
            }
    }


    private fun initMeasurementMatrix(){
        for (row in 0 until Constants.maxNumberOfPoints+1){
            val tableRow = TableRow(this)
            distanceMatrix.addView(tableRow,
                distanceMatrix.width,
                Constants.distanceMatrixSize / (Constants.maxNumberOfPoints + 1))

            for (col in 0 until Constants.maxNumberOfPoints+1){
                val textView = TextView(this)
                textView.setTextColor(Color.WHITE)
                if (row==0){
                    if (col==0){
                        textView.text = "cm"
                    }
                    else{
                        textView.text = (col-1).toString()
                    }
                }
                else{
                    if (col==0){
                        textView.text = (row-1).toString()
                    }
                    else if(row==col){
                        textView.text = "-"
                        multipleDistances[row-1][col-1] = textView
                    }
                    else{
                        textView.text = zero_distance
                        multipleDistances[row-1][col-1] = textView
                    }
                }
                tableRow.addView(textView,
                    tableRow.layoutParams.width / (Constants.maxNumberOfPoints + 1),
                    tableRow.layoutParams.height)
            }

        }
    }


    private fun initRenderable() {
        MaterialFactory.makeTransparentWithColor(
            this,
            arColor(Color.RED)
        )
            .thenAccept { material: Material? ->
                markerRenderable = ShapeFactory.makeSphere(
                    0.02f,
                    Vector3.zero(),
                    material
                )
                markerRenderable!!.isShadowCaster = false
                markerRenderable!!.isShadowReceiver = false
            }
            .exceptionally {
                val builder = AlertDialog.Builder(this)
                builder.setMessage(it.message).setTitle("Error")
                val dialog = builder.create()
                dialog.show()
                return@exceptionally null
            }

        ViewRenderable
            .builder()
            .setView(this, R.layout.distance_text_layout)
            .build()
            .thenAccept {
                distanceCardViewRenderable = it
                distanceCardViewRenderable!!.isShadowCaster = false
                distanceCardViewRenderable!!.isShadowReceiver = false
            }
            .exceptionally {
                val builder = AlertDialog.Builder(this)
                builder.setMessage(it.message).setTitle("Error")
                val dialog = builder.create()
                dialog.show()
                return@exceptionally null
            }
    }

    private fun configureSpinner(){
        distanceMode = distanceModeArrayList[0]
        distanceModeSpinner = findViewById(R.id.distance_mode_spinner)
        val distanceModeAdapter = ArrayAdapter(
            applicationContext,
            android.R.layout.simple_spinner_item,
            distanceModeArrayList
        )
        distanceModeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        distanceModeSpinner.adapter = distanceModeAdapter
        distanceModeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?,
                                        view: View?,
                                        position: Int,
                                        id: Long) {
                val spinnerParent = parent as Spinner
                distanceMode = spinnerParent.selectedItem as String
                clearAllAnchors()
                setMode()
                toastMode()
                if (distanceMode == distanceModeArrayList[2]){
                    val layoutParams = distanceMatrix.layoutParams
                    layoutParams.height = Constants.distanceMatrixSize
                    distanceMatrix.layoutParams = layoutParams
                    initMeasurementMatrix()
                }
                else{
                    val layoutParams = distanceMatrix.layoutParams
                    layoutParams.height = 0
                    distanceMatrix.layoutParams = layoutParams
                }
                Log.i(TAG, "Selected arcore focus on ${distanceMode}")
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {
                clearAllAnchors()
                setMode()
                toastMode()
            }
        }
    }

    private fun setMode(){
        distanceModeTextView!!.text = distanceMode
    }

    private fun clearButton(){
        clearButton = findViewById(R.id.clearButton)
        clearButton.setOnClickListener(object: View.OnClickListener {
            override fun onClick(v: View?) {
                clearAllAnchors()
            }
        })
    }

    private fun clearAllAnchors(){
        placedAnchors.clear()
        for (anchorNode in placedAnchorNodes){
            arFragment!!.arSceneView.scene.removeChild(anchorNode)
            anchorNode.isEnabled = false
            anchorNode.anchor!!.detach()
            anchorNode.setParent(null)
        }
        placedAnchorNodes.clear()
        midAnchors.clear()
        for ((k,anchorNode) in midAnchorNodes){
            arFragment!!.arSceneView.scene.removeChild(anchorNode)
            anchorNode.isEnabled = false
            anchorNode.anchor!!.detach()
            anchorNode.setParent(null)
        }
        midAnchorNodes.clear()
        for (i in 0 until Constants.maxNumberOfPoints){
            for (j in 0 until Constants.maxNumberOfPoints){
                if (multipleDistances[i][j] != null){
                    multipleDistances[i][j]!!.text = if(i==j) "-" else zero_distance
                }
            }
        }
        fromGroundNodes.clear()
    }


    private fun placeAnchor(hitResult: HitResult, renderable: Renderable,renderFlag: Boolean){
        val anchor = hitResult.createAnchor()
        placedAnchors.add(anchor)

        val anchorNode = AnchorNode(anchor).apply {
            isSmoothed = true
            setParent(arFragment!!.arSceneView.scene)
        }
        placedAnchorNodes.add(anchorNode)

        if(renderFlag){
            val node = TransformableNode(arFragment!!.transformationSystem).apply {
                setParent(anchorNode)
                this.renderable = renderable3D
                this.scaleController.isEnabled = false
                this.translationController.isEnabled = false
                this.rotationController.isEnabled = false
                this.select()
            }
        }

        else {
            val node = TransformableNode(arFragment!!.transformationSystem)
                .apply {
                    this.rotationController.isEnabled = false
                    this.scaleController.isEnabled = false
                    this.translationController.isEnabled = true
                    this.renderable = renderable
                    setParent(anchorNode)
                    this.select()
                }
        }

        arFragment!!.arSceneView.scene.addOnUpdateListener(this)
        arFragment!!.arSceneView.scene.addChild(anchorNode)
//        node.select()
    }


    private fun tapDistanceOf2Points(hitResult: HitResult){
        when (placedAnchorNodes.size) {
            0 -> {
                placeAnchor(hitResult, markerRenderable!!,false)
            }
            1 -> {
                placeAnchor(hitResult, markerRenderable!!,false)

                val midPosition = floatArrayOf(
                    (placedAnchorNodes[0].worldPosition.x + placedAnchorNodes[1].worldPosition.x) / 2,
                    (placedAnchorNodes[0].worldPosition.y + placedAnchorNodes[1].worldPosition.y) / 2,
                    (placedAnchorNodes[0].worldPosition.z + placedAnchorNodes[1].worldPosition.z) / 2)
                val quaternion = floatArrayOf(0.0f,0.0f,0.0f,0.0f)
                val pose = Pose(midPosition, quaternion)

                placeMidAnchor(pose, distanceCardViewRenderable!!)
            }
            else -> {
                clearAllAnchors()
                placeAnchor(hitResult, markerRenderable!!,false)
            }
        }
    }


    private fun placeMidAnchor(pose: Pose, renderable: Renderable, between: Array<Int> = arrayOf(0,1)){
        val midKey = "${between[0]}_${between[1]}"
        val anchor = arFragment!!.arSceneView.session!!.createAnchor(pose)
        midAnchors.put(midKey, anchor)

        val anchorNode = AnchorNode(anchor).apply {
            isSmoothed = true
            setParent(arFragment!!.arSceneView.scene)
        }
        midAnchorNodes.put(midKey, anchorNode)

        val node = TransformableNode(arFragment!!.transformationSystem)
            .apply{
                this.rotationController.isEnabled = false
                this.scaleController.isEnabled = false
                this.translationController.isEnabled = true
                this.renderable = renderable
                setParent(anchorNode)
            }
        arFragment!!.arSceneView.scene.addOnUpdateListener(this)
        arFragment!!.arSceneView.scene.addChild(anchorNode)
    }

    private fun tapDistanceOfMultiplePoints(hitResult: HitResult) {
        var renderFlag : Boolean = false
        if (placedAnchorNodes.size >= Constants.maxNumberOfPoints )  {
            clearAllAnchors()
        }
        else {
            if (placedAnchors.size == Constants.maxNumberOfPoints - 1) {
                renderFlag = true
            }
            ViewRenderable
                .builder()
                .setView(this, R.layout.point_text_layout)
                .build()
                .thenAccept {
                    it.isShadowReceiver = false
                    it.isShadowCaster = false
                    pointTextView = it.view as TextView
                    pointTextView.text = placedAnchors.size.toString()
                    placeAnchor(hitResult, it, renderFlag)
                }
                .exceptionally {
                    val builder = AlertDialog.Builder(this)
                    builder.setMessage(it.message).setTitle("Error")
                    val dialog = builder.create()
                    dialog.show()
                    return@exceptionally null
                }

        }
        Log.i(TAG, "Number of anchors: ${placedAnchorNodes.size}")
    }

    @SuppressLint("SetTextI18n")
    override fun onUpdate(frameTime: FrameTime) {
        when(distanceMode) {
            distanceModeArrayList[0] -> {
                measureDistanceFromCamera()
            }
            distanceModeArrayList[1] -> {
                measureDistanceOf2Points()
            }
            distanceModeArrayList[2] -> {
                measureMultipleDistances()
            }
            else -> {
                measureDistanceFromCamera()
            }
        }
    }

    private fun measureDistanceFromCamera(){
        val frame = arFragment!!.arSceneView.arFrame
        if (placedAnchorNodes.size >= 1) {
            val distanceMeter = calculateDistance(
                placedAnchorNodes[0].worldPosition,
                frame!!.camera.pose)
            measureDistanceOf2Points(distanceMeter)
        }
    }

    private fun measureDistanceOf2Points(){
        if (placedAnchorNodes.size == 2) {
            val distanceMeter = calculateDistance(
                placedAnchorNodes[0].worldPosition,
                placedAnchorNodes[1].worldPosition)
            measureDistanceOf2Points(distanceMeter)
        }
    }

    private fun measureDistanceOf2Points(distanceMeter: Float){
        val distanceTextCM = makeDistanceTextWithCM(distanceMeter)
        val textView = (distanceCardViewRenderable!!.view as LinearLayout)
            .findViewById<TextView>(R.id.distanceCard)
        textView.text = distanceTextCM
        Log.d(TAG, "distance: ${distanceTextCM}")
    }

    private fun measureMultipleDistances(){
        if (placedAnchorNodes.size > 1){
            for (i in 0 until placedAnchorNodes.size){
                for (j in i+1 until placedAnchorNodes.size){
                    val distanceMeter = calculateDistance(
                        placedAnchorNodes[i].worldPosition,
                        placedAnchorNodes[j].worldPosition)
                    val distanceCM = changeUnit(distanceMeter, "cm")
                    val distanceCMFloor = "%.2f".format(distanceCM)
                    multipleDistances[i][j]!!.text = distanceCMFloor
                    multipleDistances[j][i]!!.text = distanceCMFloor
                }
            }
        }
    }

    private fun makeDistanceTextWithCM(distanceMeter: Float): String{
        val distanceCM = changeUnit(distanceMeter, "cm")
        val distanceCMFloor = "%.2f".format(distanceCM)
        return "${distanceCMFloor} cm"
    }

    private fun calculateDistance(x: Float, y: Float, z: Float): Float{
        return sqrt(x.pow(2) + y.pow(2) + z.pow(2))
    }


    private fun calculateDistance(objectPose0: Vector3, objectPose1: Pose): Float{
        return calculateDistance(
            objectPose0.x - objectPose1.tx(),
            objectPose0.y - objectPose1.ty(),
            objectPose0.z - objectPose1.tz()
        )
    }

    private fun calculateDistance(objectPose0: Vector3, objectPose1: Vector3): Float{
        return calculateDistance(
            objectPose0.x - objectPose1.x,
            objectPose0.y - objectPose1.y,
            objectPose0.z - objectPose1.z
        )
    }

    private fun changeUnit(distanceMeter: Float, unit: String): Float{
        return when(unit){
            "cm" -> distanceMeter * 100
            "mm" -> distanceMeter * 1000
            else -> distanceMeter
        }
    }

    private fun toastMode(){
        Toast.makeText(this@MeasurementAPI,
            when(distanceMode){
                distanceModeArrayList[0] -> "Find plane and tap somewhere"
                distanceModeArrayList[1] -> "Find plane and tap 2 points"
                distanceModeArrayList[2] -> "Find plane and tap multiple points"
                else -> "???"
            },
            Toast.LENGTH_LONG)
            .show()
    }

    private fun initToast(){
        Toast.makeText(this@MeasurementAPI,"Make sure the Environment is well lit",Toast.LENGTH_LONG).show()
    }


    private fun checkDeviceSupportStatus(activity: Activity){
        val openGlVersionString =
            (Objects.requireNonNull(activity
                .getSystemService(Context.ACTIVITY_SERVICE)) as ActivityManager)
                .deviceConfigurationInfo
                .glEsVersion
        if (openGlVersionString.toDouble() < MIN_OPENGL_VERSION) {
            Log.e(TAG, "Measure requires OpenGL ES ${MIN_OPENGL_VERSION} later")

            Toast.makeText(activity,
                "Measure requires OpenGL ES ${MIN_OPENGL_VERSION} or later",
                Toast.LENGTH_LONG)
                .show()

            Toast.makeText(activity,
                "Exiting application",
                Toast.LENGTH_LONG)
                .show()

            activity.finish()
        }
    }
}