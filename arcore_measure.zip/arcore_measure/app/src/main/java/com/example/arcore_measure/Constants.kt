package com.example.arcore_measure

object Constants {
    const val distanceMatrixSize = 300
    const val arrowViewSize = 45
    const val maxNumberOfPoints = 5

}